package com.tylerbeck.productsandcategories.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.tylerbeck.productsandcategories.models.Category;
import com.tylerbeck.productsandcategories.models.Product;
import com.tylerbeck.productsandcategories.service.CategoryService;
import com.tylerbeck.productsandcategories.service.ProductService;

@Controller
public class ProductCategoryController {
	
	@Autowired
	private ProductService pService;
	
	@Autowired
	private CategoryService cService;
	
	@GetMapping("")
	public String index(@ModelAttribute("product") Product product, @ModelAttribute("category") Category category, Model viewModel) {
		viewModel.addAttribute("products", pService.findAllProducts());
		viewModel.addAttribute("categories", cService.findAll());
		return "index.jsp";
	}
	
	@GetMapping("categories/new")
	public String addCategory(@ModelAttribute("category") Category category) {
		return "newCategory.jsp";
	}
	
	@PostMapping("categories/new")
	public String createCategory(@Valid @ModelAttribute("category") Category category, BindingResult result) {
		if(result.hasErrors()) {
			return "newCategory.jsp";
		} else {
			cService.createCategory(category);
			return "redirect:/ ";
		}
	}
	
	@GetMapping("products/new")
	public String addProduct(@ModelAttribute("product") Product product) {
		return "newProduct.jsp";
	}
	
	@PostMapping("products/new")
	public String createProduct(@Valid @ModelAttribute("product") Product product, BindingResult result) {
		if(result.hasErrors()) {
			return "newProduct.jsp";
		} else {
			pService.createProduct(product);
			return "redirect:/ ";
		}
	}
	
	
	//THESE TWO CONTROLLERS ARE WHERE THINGS GET WEIRD FOR ME
	@GetMapping("products/{id}")
	public String showProduct(@PathVariable("id") Long id, @ModelAttribute("product") Product product, Model viewModel) {
		viewModel.addAttribute("product", pService.getOneProduct(id));
		viewModel.addAttribute("unassigned", cService.findAll());
		return "showProduct.jsp";
	}
	
	@PostMapping("products/add/{id}")
	public String addCatToProduct(@PathVariable("id") Long id) {
		
		//NOTHING HERE YET AS I NOW JUST GET ERRORS TRYING TO LOAD THE PAGE
		return "redirect:/products/{id}";
	}
}
